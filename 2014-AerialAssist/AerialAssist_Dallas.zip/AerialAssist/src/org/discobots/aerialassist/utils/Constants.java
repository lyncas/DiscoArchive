package org.discobots.aerialassist.utils;

public class Constants {

    public static final boolean DEBUG = true;

    public static double AutonomousStraightTank_YkP = 0;
    public static double AutonomousStraightTank_YkI = 0;
    public static double AutonomousStraightTank_YkD = 0;
    public static double AutonomousStraightTank_XkP = 0;
    public static double AutonomousStraightTank_XkI = 0;
    public static double AutonomousStraightTank_XkD = 0;
}

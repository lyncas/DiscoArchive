/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package res;

/**
 *
 * @author sam
 */
public final class MenuStrings {

    private MenuStrings() {
    }
    ;


    public static final String menu_title = "Grid Options";
    public static final String	btn_fast_refresh = "Fast Refresh",
				bth_fast_refresh_tooltip = "Easier to see differences, but doesn't look as cool",
				btn_high_contrast = "High Contrast",
				btn_high_contrast_tooltip = "Turn on high contrast mode",
				btn_disp_numbers = "Display Numerical Output",
				btn_disp_numbers_tooltip = "Toggle display of numbers on grid.";
    public static final String	spinner_resolution_tooltip = "Change grid resolution. Resize to view changes";
}

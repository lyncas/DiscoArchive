
package disco.utils;

import disco.commands.CommandBase;
import disco.commands.drivetrain.AssistedTank;


public class Modes {
    public static boolean modeShooterPID = true;
    public static boolean modeDrivePID = true;
    public static boolean modeDriveTank = true;    
}
